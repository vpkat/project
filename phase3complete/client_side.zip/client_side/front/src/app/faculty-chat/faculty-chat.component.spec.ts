import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FacultyChatComponent } from './faculty-chat.component';

describe('FacultyChatComponent', () => {
  let component: FacultyChatComponent;
  let fixture: ComponentFixture<FacultyChatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FacultyChatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FacultyChatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
