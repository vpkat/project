package com.app.pojos;

import java.time.LocalDate;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "student_info")
public class StudentInfo 
{
	@JsonProperty(value="no")
	Integer sid;
	double ssc,hsc;
	String Project_name;
	LocalDate passout;
	int gap;
	String gradution_branch;
	
	private User users;

// <================================= Constructor Start ========================================>

	public StudentInfo()
	{
       System.out.println("Inside StudentInfo ctor");
    }

	public StudentInfo(double ssc, double hsc, String project_name, LocalDate passout, int gap, String gradution_branch)
	{
		super();
		this.ssc = ssc;
		this.hsc = hsc;
		Project_name = project_name;
		this.passout = passout;
		this.gap = gap;
		this.gradution_branch = gradution_branch;
	}


// <================================= Constructor end ========================================>
	
	
// <================================= Getter Start ========================================>
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getSid() {
		return sid;
	}

	public double getSsc() {
		return ssc;
	}

	public double getHsc() {
		return hsc;
	}

	public String getProject_name() {
		return Project_name;
	}

	public LocalDate getPassout() {
		return passout;
	}

	public int getGap() {
		return gap;
	}

	public String getGradutionBranch() {
		return gradution_branch;
	}

	@OneToOne
	@JoinColumn(name = "uid")
	@JsonIgnore
	public User getUsers() {
		return users;
	}


// <================================= Getter End ========================================>

	
// <================================= Setter Start ========================================>

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public void setSsc(double ssc) {
		this.ssc = ssc;
	}

	public void setHsc(double hsc) {
		this.hsc = hsc;
	}

	public void setProject_name(String project_name) {
		Project_name = project_name;
	}

	public void setPassout(LocalDate passout) {
		this.passout = passout;
	}

	public void setGap(int gap) {
		this.gap = gap;
	}

	public void setGradutionBranch(String gradution_branch) {
		this.gradution_branch = gradution_branch;
	}

	public void setUsers(User users) {
		this.users = users;
	}



// <================================= Setter End ========================================>

// <================================= toString Start ========================================>
 
	@Override
	public String toString() {
		return "StudentInfo [sid=" + sid + ", ssc=" + ssc + ", hsc=" + hsc + ", Project_name=" + Project_name
				+ ", passout=" + passout + ", gap=" + gap + ", gradution_branch=" + gradution_branch + "]";
	}


	
// <================================= toString End ========================================>

	
}
