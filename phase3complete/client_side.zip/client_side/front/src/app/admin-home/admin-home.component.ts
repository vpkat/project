import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.css']
})
export class AdminHomeComponent implements OnInit {

  users:any;
  constructor(private service:DataService,
    private authService:AuthService, 
    private router:Router) { }

  ngOnInit()
  {
   this.users= JSON.parse(window.sessionStorage.getItem("user"));
   
   console.log(this.users);
  }
  logout()
  {
   this.authService.SignOut();
   this.router.navigate(['login']);
  }

}
