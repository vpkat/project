import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {
 


 

  constructor(public http:HttpClient )
   { }
   Select()
   {
     return this.http.get("http://localhost:8080/Student_Portal_1/admin");
   }

  SelectbyNo(id)
    {
      return this.http.get("http://localhost:8080/Student_Portal_1/admin/"+id);
    }

  CheckUser(user) 
  {
    return this.http.post("http://localhost:8080/Student_Portal_1/user/validation/"+user.id,user);
  }

  Update(user)
  {
    return this.http.put("http://localhost:8080/Student_Portal_1/admin/"+user.id,user);
  }

  Insert(user) 
  {
    return this.http.post("http://localhost:8080/Student_Portal_1/admin/",user);
  }

  Delete(id) 
  {
    return this.http.delete("http://localhost:8080/Student_Portal_1/admin/"+id);
  }
  SelectNotice() 
  {
    return this.http.get("http://localhost:8080/Student_Portal_1/admin/notice_all");
  }

  InsertNotice(notice)
 {
  return this.http.post("http://localhost:8080/Student_Portal_1/admin/notice/",notice);
 }
 DeleteNotice(nid) 
 {
  return this.http.delete("http://localhost:8080/Student_Portal_1/admin/delete_notice/"+nid);
 }
 SelectNoticeByType(course)
 {
  return this.http.post("http://localhost:8080/Student_Portal_1/admin/notices_type/",course);

 }
 InsertStudentInfo(user,std)
 {
  return this.http.post("http://localhost:8080/Student_Portal_1/user/add_student_info/"+user.id,std);

 }

}
