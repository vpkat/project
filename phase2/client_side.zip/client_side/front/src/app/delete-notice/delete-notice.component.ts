import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-delete-notice',
  templateUrl: './delete-notice.component.html',
  styleUrls: ['./delete-notice.component.css']
})
export class DeleteNoticeComponent implements OnInit {

  constructor(private route:ActivatedRoute,
    private router:Router,
    private service:DataService) {}

    ngOnInit()
    {
      this.route.paramMap.subscribe((result)=>{
        console.log(result);
        let id=result.get("id");
         console.log(id);
         let observabelResult = this.service.DeleteNotice(id);
   
         observabelResult.subscribe((data)=>{
           console.log(data);
   
            this.router.navigate(['/notice']);
         })
       });
    }

}
