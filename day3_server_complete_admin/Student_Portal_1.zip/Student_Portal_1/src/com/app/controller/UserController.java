package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.app.dao.IAdminDao;
import com.app.dao.IUserDao;
import com.app.pojos.Address;
import com.app.pojos.StudentInfo;
import com.app.pojos.User;

@RestController
@CrossOrigin
@RequestMapping("/user")
public class UserController 
{
	@Autowired
	private IAdminDao dao;
	
	@Autowired
	private IUserDao daou;

//----------------------------------------------Address methods start-----------------------------------------------------------
	@PostMapping("/add_address")
	public ResponseEntity<?> addAddress(@RequestBody Address a)
	{
		System.out.println("Inside add address method "+a);
		//remove below line in angular
		int id=1;
		User u=dao.getUserById(id);
		System.out.println("user in add address method "+u);
		u.addAddress(a);
		
		try {
			return new ResponseEntity<User>(daou.addAddress(u), HttpStatus.CREATED);
		} catch (RuntimeException e1) {
			e1.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PutMapping("/update_address")
	public ResponseEntity<?> updateAddress(@RequestBody Address a) 
	{
		System.out.println("Inside update address method "+a);
		//remove below line in angular
		int id=1;
		User u=dao.getUserById(id);		
		System.out.println("in add address dtls " + u);
		Address olda=u.getAdr();
		
		System.out.println("inside edit address "+olda);
		
		
		       daou.updateAddress(olda,a);
		
		return null;

	}
	
//----------------------------------------------Address methods end-----------------------------------------------------------

  

//----------------------------------------------Student methods start-----------------------------------------------------------
	
	@PostMapping("/add_student_info")
	public ResponseEntity<?> addStudentInfo(@RequestBody StudentInfo s)
	{
		System.out.println("Inside add StudentInfo method "+s);
		//remove below line in angular
		int id=1;
		User u=dao.getUserById(id);
		System.out.println("user in add StudentInfo method "+u);
		u.addStudentInfo(s);
		
		try {
			return new ResponseEntity<User>(daou.addStudenInfo(u), HttpStatus.CREATED);
		} catch (RuntimeException e1) {
			e1.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PutMapping("/update_student_info")
	public ResponseEntity<?> updateStudentInfo(@RequestBody StudentInfo s) 
	{
		System.out.println("Inside update StudentInfo method "+s);
		//remove below line in angular
		int id=1;
		User u=dao.getUserById(id);		
		System.out.println("in add StudentInfo dtls " + u);
		StudentInfo oldStudentInfo=u.getStudent();
		
		System.out.println("inside StudentInfo address "+oldStudentInfo);
		
		
		       daou.updateStudentInfo(oldStudentInfo,s);
		
		return null;

	}
	
//----------------------------------------------Student methods end-----------------------------------------------------------

	
//------------------------------------------- Login start -----------------------------------------------------------------
	
	@PostMapping("/validation/{id}")
	public ResponseEntity<?> validateUser(@PathVariable int id,@RequestBody User u)
	{
		System.out.println("=====================================================> "+id);

		System.out.println("=====================================================> "+u);
		
		User user=daou.validateUser(u);
		if(u != null)
			return new ResponseEntity<User>(user, HttpStatus.CREATED);
		return new ResponseEntity<User>(user,HttpStatus.BAD_REQUEST);
         
	}
	
//------------------------------------------- Login end ------------------------------------------------------------------


}
