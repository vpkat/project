package com.app.dao;

import java.util.List;

import com.app.pojos.Chat;
import com.app.pojos.User;

public interface IChatDao {

	List<Chat> getAllChat();

	User addChat(User u);

}
