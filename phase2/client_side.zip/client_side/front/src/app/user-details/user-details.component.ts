import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {
 public users:any;
  constructor(private service:DataService,
          private authService:AuthService,
            private router:Router) { }

  ngOnInit() {
    let observalbleResult=this.service.Select();
    observalbleResult.subscribe((result)=>{
      //console.log(result);
      this.users=result;
      console.log(result);    
    })
     
  }

  logout()
  {
   this.authService.SignOut();
   this.router.navigate(['login']);
  }

}
