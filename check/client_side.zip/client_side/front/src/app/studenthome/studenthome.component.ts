import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-studenthome',
  templateUrl: './studenthome.component.html',
  styleUrls: ['./studenthome.component.css']
})
export class StudenthomeComponent implements OnInit {
u:any;
  users:any;
  notices:any;
  public studentCheck:boolean=false;
  public addressCheck:boolean=false;
  constructor(private service:DataService,
    private authService:AuthService, 
    private router:Router) { }
  ngOnInit()
   {
    this.u= JSON.parse(window.sessionStorage.getItem("user"));
   
    let id=this.u.id;
    let observalbleRes=this.service.SelectbyNo(id);
    observalbleRes.subscribe((result)=>{
      //console.log(result);
      this.users=result;
      console.log(result);  
      if(this.users.student == null)
      {
       this.studentCheck=true;
       console.log(this.studentCheck);
      }
      if(this.users.adr == null)
      {
        this.addressCheck=true;
        console.log(this.addressCheck);
      } 
    })
  
    let course=this.u;
    let observalbleResult=this.service.SelectNoticeByType(course);
    observalbleResult.subscribe((result)=>{
      //console.log(result);
      this.notices=result;
      console.log(result);
    });
  
   }
   logout()
   {
    this.authService.SignOut();
    this.router.navigate(['login']);
   }

}
