import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-studenthome',
  templateUrl: './studenthome.component.html',
  styleUrls: ['./studenthome.component.css']
})
export class StudenthomeComponent implements OnInit {

  users:any;
  notices:any;
  constructor(private service:DataService,
    private authService:AuthService, 
    private router:Router) { }
  ngOnInit()
   {
    this.users= JSON.parse(window.sessionStorage.getItem("user"));
   
    console.log(this.users);
     let course=this.users;
    let observalbleResult=this.service.SelectNoticeByType(course);
    observalbleResult.subscribe((result)=>{
      //console.log(result);
      this.notices=result;
      console.log(result);
    });
  
   }
   logout()
   {
    this.authService.SignOut();
    this.router.navigate(['login']);
   }

}
