import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-add-notice',
  templateUrl: './add-notice.component.html',
  styleUrls: ['./add-notice.component.css']
})
export class AddNoticeComponent implements OnInit {

  notice={
    "course":"",
    "notice":"",
    "type":""

  }
  constructor(private route:ActivatedRoute,
    private router:Router,
    private service:DataService) {}
    ngOnInit() 
    { }
    InsertNotice()
    {
      console.log(this.notice);
  
      let observabelResult = this.service.InsertNotice(this.notice);
      observabelResult.subscribe((result)=>{
        console.log(result);
  
        this.router.navigate(['/notice']);
      })
    }


}
