package com.app.pojos;

import javax.persistence.*;

@Entity
@Table(name = "faculty")

public class Faculty 
{
   Integer fid;
   String education_details;
   User users;
   
//<================================= Constructor Start ==================================>
   
   public Faculty()
   {
     System.out.println("Inside Faculty ctor");
   }

   public Faculty(String education_details)
   {
		super();
		this.education_details = education_details;
   }

   
//<================================= Constructor End ==================================>
   
//<================================= Getter Start ==================================>
   
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   public Integer getFid() {
		return fid;
	}

	public String getEducation_details() {
		return education_details;
	}

	@OneToOne
	@JoinColumn(name = "uid")
	public User getUsers() {
		return users;
	}


//<================================= Getter End ==================================>

//<================================= Setter Start ================================>
	
	public void setFid(Integer fid) {
		this.fid = fid;
	}

	public void setEducation_details(String education_details) {
		this.education_details = education_details;
	}

	public void setUsers(User users) {
		this.users = users;
	}
	
//<================================= Setter End ==================================>

//<================================= toString Start ================================>

	@Override
	public String toString() {
		return "Faculty [fid=" + fid + ", education_details=" + education_details + "]";
	}
	
//<================================= toString End ==================================>

}
