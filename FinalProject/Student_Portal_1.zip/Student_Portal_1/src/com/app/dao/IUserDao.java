package com.app.dao;

import java.util.List;

import com.app.pojos.Address;
import com.app.pojos.StudentInfo;
import com.app.pojos.User;

public interface IUserDao
{

	User addAddress(User u);

    void updateAddress(Address olda, Address a);

	User addStudenInfo(User u);

	void updateStudentInfo(StudentInfo oldStudentInfo, StudentInfo s);
    
	User validateUser(User u);

}
