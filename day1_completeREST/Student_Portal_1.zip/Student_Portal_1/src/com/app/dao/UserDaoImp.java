package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Address;
import com.app.pojos.StudentInfo;
import com.app.pojos.User;

@Repository
@Transactional
public class UserDaoImp implements IUserDao {

	@Autowired
	SessionFactory sf;
	@Override
	public User addAddress(User u) 
	{
		sf.getCurrentSession().update(u);
		return u;
	}
	
	@Override
	public void updateAddress(Address olda, Address a) 
	{
           olda.setCellNo(a.getCellNo());
           olda.setCity(a.getCity());
           olda.setCountry(a.getCountry());
           olda.setState(a.getState());
           
           sf.getCurrentSession().update(olda);
          
	}

	@Override
	public User addStudenInfo(User u) 
	{
		sf.getCurrentSession().update(u);
		return u;
	}

	@Override
	public void updateStudentInfo(StudentInfo oldStudentInfo, StudentInfo s)
	{
		oldStudentInfo.setGap(s.getGap());
		oldStudentInfo.setGradutionBranch(s.getGradutionBranch());
		oldStudentInfo.setHsc(s.getHsc());
		oldStudentInfo.setPassout(s.getPassout());
		oldStudentInfo.setProject_name(s.getProject_name());
		oldStudentInfo.setSsc(s.getSsc());
		
		sf.getCurrentSession().update(oldStudentInfo);
	}



}
