import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { RouterModule,Routes } from '@angular/router';

import {NgModel,NgForm,FormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AuthService } from './auth.service';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { StudenthomeComponent } from './studenthome/studenthome.component';
import { UserDetailsComponent } from './user-details/user-details.component';
import { RegisterUserComponent } from './register-user/register-user.component';
import { EditUserComponent } from './edit-user/edit-user.component';
import { DeleteByAdminComponent } from './delete-by-admin/delete-by-admin.component';
import { NoticeHomeComponent } from './notice-home/notice-home.component';
import { AddNoticeComponent } from './add-notice/add-notice.component';
import { DeleteNoticeComponent } from './delete-notice/delete-notice.component';
import { StudentDetailsComponent } from './student-details/student-details.component';
import { EditStudentComponent } from './edit-student/edit-student.component';
import { AddStudentAddressComponent } from './add-student-address/add-student-address.component';
import { AddStudentInfoComponent } from './add-student-info/add-student-info.component';
import { AddStudentDetailsControllerComponent } from './add-student-details-controller/add-student-details-controller.component';


import { CommonModule } from '@angular/common';
import { FacultyNoticeComponent } from './faculty-notice/faculty-notice.component';
import { AddFacultyNoticeComponent } from './add-faculty-notice/add-faculty-notice.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    AdminHomeComponent,
    PagenotfoundComponent,
    StudenthomeComponent,
    UserDetailsComponent,
    RegisterUserComponent,
    EditUserComponent,
    DeleteByAdminComponent,
    NoticeHomeComponent,
    AddNoticeComponent,
    DeleteNoticeComponent,
    StudentDetailsComponent,
    EditStudentComponent,
    AddStudentAddressComponent,
    AddStudentInfoComponent,
    AddStudentDetailsControllerComponent,
    FacultyNoticeComponent,
    AddFacultyNoticeComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    RouterModule.forRoot([
      {path:"",redirectTo:"/login",pathMatch:"full"},
      {path:"login",component:LoginComponent},
      {path:"user_details",component:UserDetailsComponent},
      {path:"register_user",component:RegisterUserComponent},
      {path:"edit_user/:id",component:EditUserComponent},
      {path:"delete/:id",component:DeleteByAdminComponent},
      {path:"notice",component:NoticeHomeComponent},
      {path:"admin_home",component:AdminHomeComponent,canActivate:[AuthService]},
      {path:"student_home",component:StudenthomeComponent,canActivate:[AuthService]},
      {path:"faculty_home",component:HomeComponent,canActivate:[AuthService]},
      {path:"add_notice",component:AddNoticeComponent},
      {path:"delete_notice/:id",component:DeleteNoticeComponent},
       {path:"edit_student_details",component:EditStudentComponent},
      {path:"student_details",component:StudentDetailsComponent},
      {path:"add_student_details_controller",component:AddStudentDetailsControllerComponent},
      {path:"add_student_address",component:AddStudentAddressComponent},
      {path:"edit_student_address",component:AddStudentInfoComponent},
      {path:"faculty_notice",component:FacultyNoticeComponent},
      {path:"faculty_add_notice",component:AddFacultyNoticeComponent},
      {path:"**",component:PagenotfoundComponent}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
