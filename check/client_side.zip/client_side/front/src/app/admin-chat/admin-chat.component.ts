import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../data.service';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-admin-chat',
  templateUrl: './admin-chat.component.html',
  styleUrls: ['./admin-chat.component.css']
})
export class AdminChatComponent implements OnInit {

  users:any;
  addrNotEmpty:boolean=false;
  now:number;
  chat=
  {
    "cid":"",
    "role":"",
    "message":"",
    "names":"",

  }
  did="";
  u:any;
  curDate=new Date();
  constructor(private service:DataService,
    private authService:AuthService, 
    private router:Router
    ) 
    { 
      setInterval(() => {
        this.now = Date.now();
        this.ngOnInit();

      }, 1);

    }
  ngOnInit()
   {
    this.users= JSON.parse(window.sessionStorage.getItem("user"));
   
    console.log(this.users);
       // this.u=this.users;
         let id=this.users.id;
 
    let observalbleResult=this.service.SelectChat();
    observalbleResult.subscribe((result)=>{
 
    
        this.u=result;
    
      
      console.log(result);   
    })
  }
  Insert()
  {
    console.log(this.users.id);
    console.log(this.chat);
    console.log(this.users);
    this.chat.role=this.users.role;
    let observabelResult = this.service.InsertChat(this.users,this.chat);
    observabelResult.subscribe((result)=>{
      console.log(result);
       this.ngOnInit();
      this.router.navigate(['/admin_chat_page']);
    })
  }

  Delete()
  {
    console.log(this.did);
    
    let observabelResult = this.service.DeleteBulk(this.did);
    observabelResult.subscribe((result)=>{
      console.log(result);
      this.ngOnInit();

      this.router.navigate(['/admin_chat_page']);
    })
  }

}
