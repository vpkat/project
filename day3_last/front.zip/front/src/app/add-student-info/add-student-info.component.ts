import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-student-info',
  templateUrl: './add-student-info.component.html',
  styleUrls: ['./add-student-info.component.css']
})
export class AddStudentInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
