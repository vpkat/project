import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-edit-student',
  templateUrl: './edit-student.component.html',
  styleUrls: ['./edit-student.component.css']
})
export class EditStudentComponent implements OnInit {
  
  public userdetails:any;
  public std:any;
  users: any;
  u:any;
  i:any;
  constructor(private route:ActivatedRoute,
    private router:Router,
    private service:DataService) 
  { }
    ngOnInit() 
    {
      // this.route.paramMap.subscribe((result)=>{
      //   let id=result.get("id");
  
   
      //    let observabelResult = this.service.SelectbyNo(id);
      //     console.log(observabelResult);
      //     observabelResult.subscribe((data)=>{
      //       console.log(data);
    
      //       this.userdetails=data;
      //     })
         
      // });
      this.users= JSON.parse(window.sessionStorage.getItem("user"));
    
        this.i=this.users.id;
          console.log(this.i);
            let observabelResult = this.service.SelectbyNo(this.i);
          observabelResult.subscribe((data)=>{
            console.log(data);
    
            this.std=data;
            console.log(this.std);
          })
         
      // });
      // this.std=this.users.student;
      // console.log(this.users);
      console.log("std");
      console.log(this.std);
    }
    Update()
    {
      console.log(this.userdetails);

      let observabelResult = this.service.UpdateStudent(this.users,this.std.student);
      console.log("std",this.std);
      observabelResult.subscribe((result)=>{
        console.log(result);
        console.log(this.std);

        // let id=this.users.id;
        // let observalbleResult=this.service.SelectbyNo(id);
        // observalbleResult.subscribe((result)=>{
        //   //console.log(result);
        //   console.log(result);   
        //   window.sessionStorage.removeItem("user");
        //   window.sessionStorage.setItem("user",JSON.stringify(result));


        //})
        // let id=this.users.id;
        //  let res=this.service.SelectbyNo(id);
        //  res.subscribe((result)=>{
        //    console.log(result);
        //    console.log("result");

          

        // })
        this.router.navigate(['/student_details']);
        
      })
    }
}
