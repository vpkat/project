import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-student-address',
  templateUrl: './add-student-address.component.html',
  styleUrls: ['./add-student-address.component.css']
})
export class AddStudentAddressComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
