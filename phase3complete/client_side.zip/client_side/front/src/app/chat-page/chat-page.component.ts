import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-chat-page',
  templateUrl: './chat-page.component.html',
  styleUrls: ['./chat-page.component.css'],
  providers: [DatePipe]

})
export class ChatPageComponent implements OnInit {
  users:any;
  addrNotEmpty:boolean=false;
  now:number;
  chat=
  {
    "cid":"",
    "role":"",
    "message":"",
    "names":"",

  }
  u:any;
  curDate=new Date();
  constructor(private service:DataService,
    private authService:AuthService, 
    private router:Router,
    private datePipe: DatePipe) 
    { 
      setInterval(() => {
        this.now = Date.now();
      }, 1);

    }
  ngOnInit()
   {
    this.users= JSON.parse(window.sessionStorage.getItem("user"));
   
    console.log(this.users);
       // this.u=this.users;
         let id=this.users.id;
 
    let observalbleResult=this.service.SelectChat();
    observalbleResult.subscribe((result)=>{
 
    
        this.u=result;
    
      
      console.log(result);   
    })
  }
  Insert()
  {
    console.log(this.users.id);
    console.log(this.chat);
    console.log(this.users);
    this.chat.role=this.users.role;
    let observabelResult = this.service.InsertChat(this.users,this.chat);
    observabelResult.subscribe((result)=>{
      console.log(result);
       this.ngOnInit();
      this.router.navigate(['/chat_page']);
    })
  }


}
