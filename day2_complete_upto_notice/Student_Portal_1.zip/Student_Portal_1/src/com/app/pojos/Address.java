package com.app.pojos;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name = "address")
public class Address extends AbstractEntity
{

	private String city,state,country,cellNo;
	//bi dir one to one mapping
	private User users;

// <================================= Constructor Start ========================================>

	public Address() 
	{
		// TODO Auto-generated constructor stub
	}
	public Address(String city, String state, String country, String cellNo) {
		super();
		this.city = city;
		this.state = state;
		this.country = country;
		this.cellNo = cellNo;
	}
	
// <================================= Constructor end ========================================>

	
// <================================= Getter Start ========================================>

	
	@Column(length=20)
	public String getCity() {
		return city;
	}

	@Column(length=20)
	public String getState() {
		return state;
	}

	@Column(length=20)
	public String getCountry() {
		return country;
	}

	@Column(length=10,unique=true)
	public String getCellNo() {
		return cellNo;
	}
	
	@OneToOne
	@JoinColumn(name="uid")
	@JsonIgnore
	public User getUsers() {
		return users;
	}
	
	
	
	
// <================================= Getter End ========================================>
	
// <================================= Setter Start ========================================>


	public void setCellNo(String cellNo) {
		this.cellNo = cellNo;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	
	public void setState(String state) {
		this.state = state;
	}
	
	public void setCity(String city) {
		this.city = city;
	}
	
	public void setUsers(User users) {
		this.users = users;
	}

	
// <================================= Setter End ========================================>
	

// <================================= toString Start ========================================>

	@Override
	public String toString() {
		return "Address [city=" + city + ", state=" + state + ", country=" + country + ", cellNo=" + cellNo + "]";
	}


// <================================= toString Start ========================================>
	

}
