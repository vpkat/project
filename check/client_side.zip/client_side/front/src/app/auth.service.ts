import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService implements CanActivate
{

  setSession(result)
  {
   
        window.sessionStorage.setItem("user",JSON.stringify(result));
        window.sessionStorage.setItem("active","12345advnsjdufua4654adgnj@n");
        
        return true;
    
  }

  constructor(public http:HttpClient,private router:Router) { }

  canActivate(route:ActivatedRouteSnapshot, 
    state:RouterStateSnapshot)
    {
      if(this.isLoggedIn())
      {
        return true;
      }
      else
      {
        this.router.navigate(['login']);
        return false;
      }
    }
  
    isLoggedIn()
    {
      if(window.sessionStorage.getItem("active")!=null
          && 
          window.sessionStorage.getItem("active")=="12345advnsjdufua4654adgnj@n")
          {
            return true;
          }
        else
        {
          return false;
        }
    }
    SignOut()
    {
      window.sessionStorage.setItem("active","0");
      
    }


}
