import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-student-details-controller',
  templateUrl: './add-student-details-controller.component.html',
  styleUrls: ['./add-student-details-controller.component.css']
})
export class AddStudentDetailsControllerComponent implements OnInit {

  users:any;
  std=
  {
    "sid":"",
    "be":"",
    "be_branch":"",
    "be_passout":"",
    "be_project_details":"",
    "be_project_name":"",
    "cdac_project_details":"",
    "cdac_project_name":"",
    "gap":"",
    "hsc":"",
    "me":"",
    "me_branch":"",
    "me_passout":"",
    "me_project_details":"",
    "me_project_name":"",
    "ssc":""
  }
  //std:any;
  u:any;
  address: boolean = true;
  studentinfo: boolean = true;

    constructor(private service:DataService,
    private authService:AuthService, 
    private router:Router) { }

  ngOnInit()
  {
    this.users= JSON.parse(window.sessionStorage.getItem("user"));
   
    console.log(this.users);
     this.u=this.users;
    console.log(this.users.id);

    if(this.u.student == null)
    {
      // this.u.student.be_branch=null;
      // this.u.student.be_passout=null;
      // this.u.student.be_project_details=null;
      // this.u.student.be_project_name=null;

      // this.u.student.me_branch=null;
      // this.u.student.me_passout=null;
      // this.u.student.me_project_details=null;
      // this.u.student.me_project_name=null;
      this.studentinfo=!this.studentinfo;

    }
    if(this.u.adr == null)
    {
      // this.u.student.be_branch=null;
      // this.u.student.be_passout=null;
      // this.u.student.be_project_details=null;
      // this.u.student.be_project_name=null;

      // this.u.student.me_branch=null;
      // this.u.student.me_passout=null;
      // this.u.student.me_project_details=null;
      // this.u.student.me_project_name=null;
      this.address=!this.address;

    }
  }

  Insert()
  {
    console.log(this.users.id);
    console.log(this.std);
    
    let observabelResult = this.service.InsertStudentInfo(this.users,this.std);
    observabelResult.subscribe((result)=>{
      console.log(result);

      this.router.navigate(['/student_details']);
    })
  }
  logout()
  {
   this.authService.SignOut();
   this.router.navigate(['login']);
  }

}
