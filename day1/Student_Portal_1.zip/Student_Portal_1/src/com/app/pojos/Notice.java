package com.app.pojos;

import javax.persistence.*;

@Entity
@Table(name = "notice")

public class Notice 
{
	Integer nid;
    NoticeType type;
    String notice;
    User users;
    
//<============================ Constructor Start ==========================================>

	public Notice()
    {
    	System.out.println("Inside Notice ctor");
	}

	public Notice(NoticeType type, String notice) {
		super();
		this.type = type;
		this.notice = notice;
	}
	
//<============================ Constructor Start ==========================================>
	

//<============================ getter start ==========================================>
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getNid() {
		return nid;
	}

	@Enumerated(EnumType.STRING)
	public NoticeType getType() {
		return type;
	}

	public String getNotice() {
		return notice;
	}
	
	@ManyToOne
	@JoinColumn(name = "uid")
    public User getUsers() {
		return users;
	}


//<============================ getter end ==========================================>
    

//<============================ Setter Start ==========================================>

	
	public void setNid(Integer nid) {
		this.nid = nid;
	}

	public void setType(NoticeType type) {
		this.type = type;
	}

	public void setNotice(String notice) {
		this.notice = notice;
	}
	
	public void setUsers(User users) {
		this.users = users;
	}

//<============================ Setter End ==========================================>


//<============================ toString Start ==========================================>

	@Override
	public String toString() {
		return "Notice [nid=" + nid + ", type=" + type + ", notice=" + notice + "]";
	}
    
//<============================ toString End ==========================================>

    
}
