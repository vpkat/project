package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Chat;
import com.app.pojos.User;

@Repository
@Transactional
public class ChatDaoImpl implements IChatDao {

	@Autowired
	SessionFactory sf;
	
	@Override
	public List<Chat> getAllChat()
	{
		String jpql="select c from Chat c";
		return sf.getCurrentSession().createQuery(jpql,Chat.class).getResultList();
	}

	@Override
	public User addChat(User u) {
		
		sf.getCurrentSession().update(u);
		return u;
	}

}
