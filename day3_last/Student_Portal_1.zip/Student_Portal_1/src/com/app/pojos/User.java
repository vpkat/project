package com.app.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "users")
public class User 
{
	Integer id;
	String name;
	String email;
    Role role;
    String password;
    Course course;
    Address adr;
    StudentInfo student;
    Faculty faculty;


//	List<Notice> notice = new ArrayList<>();
 
// <================================= Constructor Start ========================================>
    public User()
    {
       System.out.println("Inside user ctor");
    }


	public User(String name, String email, Role role, String password, Course course) 
	{
		super();
		this.name = name;
		this.email = email;
		this.role = role;
		this.password = password;
		this.course = course;
	}


// <================================= Constructor End ========================================>


// <================================= getter start ========================================>

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	@Column(unique = true)
	public String getEmail() {
		return email;
	}

	@Enumerated(EnumType.STRING)
	public Role getRole() {
		return role;
	}
	
    @Enumerated(EnumType.STRING)
	public Course getCourse() {
		return course;
	}


	public String getPassword() {
		return password;
	}

	@OneToOne(mappedBy = "users",cascade=CascadeType.ALL,orphanRemoval = true)
	public StudentInfo getStudent() {
		return student;
	}
	
	@OneToOne(mappedBy = "users",cascade=CascadeType.ALL,orphanRemoval = true)
	public Faculty getFaculty() {
		return faculty;
	}

//    @OneToMany(mappedBy = "users",cascade = CascadeType.ALL,orphanRemoval = true,fetch = FetchType.EAGER)
//	public List<Notice> getNotice() {
//		return notice;
//	}
    
	@OneToOne(mappedBy = "users",cascade=CascadeType.ALL,orphanRemoval = true)
    public Address getAdr() {
		return adr;
	}
	

// <================================= getter end ========================================>
	
// <================================= setter start ========================================>
	

	public void setCourse(Course course) {
		this.course = course;
	}

//	public void setNotice(List<Notice> notice) {
//		this.notice = notice;
//	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setStudent(StudentInfo student) {
		this.student = student;
	}

	public void setFaculty(Faculty faculty) {
		this.faculty = faculty;
	}
	
	public void setAdr(Address adr) {
		this.adr = adr;
	}



// <================================= setter start ========================================>

  
// <================================= toString start ========================================>
	
	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", email=" + email + ", role=" + role + ", password=" + password
				+ ", course=" + course + "]";
	}
	

// <================================= toString start ========================================>
	
//<========================== Helper Method Start ===================================>
	
	public void addAddress(Address a)
	{
		this.adr=a;
		a.setUsers(this);
	}


	public void removeAddress(Address a)
	{
		adr=null;
		a.setUsers(null);
	}
	
	public void addStudentInfo(StudentInfo s)
	{
		this.student=s;
		s.setUsers(this);
	}


	public void removeStudentInfo(StudentInfo s)
	{
		this.student=null;
		s.setUsers(null);
	}

	
//<========================== Helper Method Start ===================================>


}
