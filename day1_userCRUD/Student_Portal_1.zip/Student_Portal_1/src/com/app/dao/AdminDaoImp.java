package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.User;

@Repository
@Transactional
public class AdminDaoImp implements IAdminDao
{
	   @Autowired
	   private SessionFactory sf;
	   
		@Override
		public List<User> getAllUser()
		{
			String jpql="select u from User u";
			return sf.getCurrentSession().createQuery(jpql,User.class).getResultList();
		}
		
		@Override
		public User getUserById(int id) 
		{
			return sf.getCurrentSession().get(User.class, id);
		}

		@Override
		public void deleteById(User u) 
		{
         		sf.getCurrentSession().delete(u);	
		}

		@Override
		public User addUserDetails(User u)
		{
            sf.getCurrentSession().persist(u);
			return u;
		}

		@Override
		public void updateUser(User oldU, User u) 
		{
              oldU.setCourse(u.getCourse());	
              oldU.setEmail(u.getEmail());
              oldU.setName(u.getName());
              oldU.setPassword(u.getPassword());
              oldU.setRole(u.getRole());
              
              sf.getCurrentSession().update(oldU);
              
		}
}
