package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Course;
import com.app.pojos.Notice;
import com.app.pojos.NoticeType;
import com.app.pojos.User;

@Repository
@Transactional
public class AdminDaoImp implements IAdminDao
{
	   @Autowired
	   private SessionFactory sf;
	   
		@Override
		public List<User> getAllUser()
		{
			String jpql="select u from User u";
			return sf.getCurrentSession().createQuery(jpql,User.class).getResultList();
		}
		
		@Override
		public User getUserById(int id) 
		{
			return sf.getCurrentSession().get(User.class, id);
		}

		@Override
		public void deleteById(User u) 
		{
         		sf.getCurrentSession().delete(u);	
		}

		@Override
		public User addUserDetails(User u)
		{
            sf.getCurrentSession().persist(u);
			return u;
		}

		@Override
		public void updateUser(User oldU, User u) 
		{
              oldU.setCourse(u.getCourse());	
              oldU.setEmail(u.getEmail());
              oldU.setName(u.getName());
              oldU.setPassword(u.getPassword());
              oldU.setRole(u.getRole());           
              sf.getCurrentSession().update(oldU);
              
		}

		@Override
		public Notice addNotice(Notice n) 
		{
			 sf.getCurrentSession().persist(n);
			return n;
		}

		@Override
		public List<Notice> getAllNotices(User u) 
		{
			System.out.println("inside admin dao");
			String jpql="select n from Notice n where n.course=:cr or n.course='ALL'";
			return sf.getCurrentSession().createQuery(jpql,Notice.class).setParameter("cr", u.getCourse()).getResultList();
		}

		@Override
		public List<Notice> getAllNotice() 
		{
            String jpql="select n from Notice n";
			return sf.getCurrentSession().createQuery(jpql,Notice.class).getResultList();
		}

		@Override
		public Notice getNoticeByid(int nid) 
		{

			String jpql="select n from Notice n where n.nid=:i";
			return sf.getCurrentSession().createQuery(jpql,Notice.class).setParameter("i",nid).getSingleResult();
		}

		@Override
		public void deleteNoticeById(Notice n) 
		{
			sf.getCurrentSession().delete(n);
		}


}
