import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-faculty-notice',
  templateUrl: './faculty-notice.component.html',
  styleUrls: ['./faculty-notice.component.css']
})
export class FacultyNoticeComponent implements OnInit {
  public notices:any;
   u:any;
  constructor(private service:DataService) { }

  ngOnInit() {

    this.u= JSON.parse(window.sessionStorage.getItem("user"));

    // let observalbleResult=this.service.SelectNotice();
    // observalbleResult.subscribe((result)=>{
    //   //console.log(result);
    //   this.notices=result;
    //   console.log(result);
    // })


      let course=this.u;
      let observalbleResult=this.service.SelectNoticeByType(course);
      observalbleResult.subscribe((result)=>{
        //console.log(result);
        this.notices=result;
        console.log(result);
      });
    
    
  
   
  }

}
