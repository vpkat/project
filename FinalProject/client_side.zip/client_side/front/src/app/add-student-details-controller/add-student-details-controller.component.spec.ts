import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddStudentDetailsControllerComponent } from './add-student-details-controller.component';

describe('AddStudentDetailsControllerComponent', () => {
  let component: AddStudentDetailsControllerComponent;
  let fixture: ComponentFixture<AddStudentDetailsControllerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddStudentDetailsControllerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddStudentDetailsControllerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
