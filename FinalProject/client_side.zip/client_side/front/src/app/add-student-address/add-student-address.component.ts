import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-student-address',
  templateUrl: './add-student-address.component.html',
  styleUrls: ['./add-student-address.component.css']
})
export class AddStudentAddressComponent implements OnInit {

  users:any;
  addr=
  {
   "id":"",
   "cellNo":"",
   "city":"",
   "country":"",
   "state":""
  }
  //std:any;
  u:any;
  address: boolean = true;
  studentinfo: boolean = true;

    constructor(private service:DataService,
    private authService:AuthService, 
    private router:Router) { }

  ngOnInit()
  {
    this.users= JSON.parse(window.sessionStorage.getItem("user"));
   
    console.log(this.users);
     this.u=this.users;
    console.log(this.users.id);

    // if(this.u.student == null)
    // {
    //   // this.u.student.be_branch=null;
    //   // this.u.student.be_passout=null;
    //   // this.u.student.be_project_details=null;
    //   // this.u.student.be_project_name=null;

    //   // this.u.student.me_branch=null;
    //   // this.u.student.me_passout=null;
    //   // this.u.student.me_project_details=null;
    //   // this.u.student.me_project_name=null;
    //   this.studentinfo=!this.studentinfo;

    // }
    // if(this.u.adr == null)
    // {
    //   // this.u.student.be_branch=null;
    //   // this.u.student.be_passout=null;
    //   // this.u.student.be_project_details=null;
    //   // this.u.student.be_project_name=null;

    //   // this.u.student.me_branch=null;
    //   // this.u.student.me_passout=null;
    //   // this.u.student.me_project_details=null;
    //   // this.u.student.me_project_name=null;
    //   this.address=!this.address;

    // }
  }

  Insert()
  {
    console.log(this.users.id);
    console.log(this.addr);
    
    let observabelResult = this.service.InsertStudentAddress(this.users,this.addr);
    observabelResult.subscribe((result)=>{
      console.log(result);

      this.router.navigate(['/student_details']);
    })
  }
}
