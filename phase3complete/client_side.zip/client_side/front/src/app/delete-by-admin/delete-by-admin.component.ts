import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-delete-by-admin',
  templateUrl: './delete-by-admin.component.html',
  styleUrls: ['./delete-by-admin.component.css']
})
export class DeleteByAdminComponent implements OnInit {

  constructor(private route:ActivatedRoute,
    private router:Router,
    private service:DataService) {}
  ngOnInit()
  {
    this.route.paramMap.subscribe((result)=>{
      let id=result.get("id");
 
       let observabelResult = this.service.Delete(id);
 
       observabelResult.subscribe((data)=>{
         console.log(data);
 
          this.router.navigate(['/user_details']);
       })
     });
  }

}
