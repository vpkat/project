package com.app.pojos;

public enum NoticeType 
{
   GENERAL,DAILY,EVENTS
}
