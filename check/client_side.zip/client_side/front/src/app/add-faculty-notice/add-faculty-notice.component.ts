import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-add-faculty-notice',
  templateUrl: './add-faculty-notice.component.html',
  styleUrls: ['./add-faculty-notice.component.css']
})
export class AddFacultyNoticeComponent implements OnInit {

  notice={
    "course":"",
    "notice":"",
    "type":""

  }
  u:any;
  constructor(private route:ActivatedRoute,
    private router:Router,
    private service:DataService) {}
    ngOnInit() 
    { 
      this.u=JSON.parse(window.sessionStorage.getItem("user"));
    }
    InsertNotice()
    {
      console.log(this.notice);
     this.notice.course=this.u.course;
      let observabelResult = this.service.InsertNotice(this.notice);
      observabelResult.subscribe((result)=>{
        console.log(result);
  
        this.router.navigate(['/faculty_notice']);
      })
    }

}
