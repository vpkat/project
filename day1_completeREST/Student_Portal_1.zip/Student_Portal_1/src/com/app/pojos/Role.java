package com.app.pojos;

public enum Role 
{
  STUDENT,FACULTY,ADMIN
}
