import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-student-details',
  templateUrl: './student-details.component.html',
  styleUrls: ['./student-details.component.css']
})
export class StudentDetailsComponent implements OnInit {
  users:any;
  addrNotEmpty:boolean=false;
  user=
  {
    "id":"",
    "course":"",
    "email":"",
    "name":"",
    "password":"",
    "role":""
  }
  use:any;
  u:any;
  s:any;
  a:any;
  adCheck:boolean=false;
  sdCheck:boolean=false;
  constructor(private service:DataService,
    private authService:AuthService, 
    private router:Router) { }
  ngOnInit()
   {
    this.users= JSON.parse(window.sessionStorage.getItem("user"));
   
    console.log(this.users);
       // this.u=this.users;
         let id=this.users.id;
 
    let observalbleResult=this.service.SelectbyNo(id);
    observalbleResult.subscribe((result)=>{
      console.log(result);
      // this.c=result;
      // if(this.c.adr == null)
      // {
      //   console.log("In null");
      //   this.addrNotEmpty=true;
      // }
      // else
      // {
      //   console.log("In not null");
      //   this.a=result;
      //   this.addrNotEmpty=false;
      // }
      //this.a=result;
      this.u=result;
      if(this.u.student != null)
      {
        this.s=result;
        this.sdCheck=true;
      }
      if(this.u.adr != null)
      {
        this.a=result;
        this.adCheck=true;
      }
      console.log("u",this.u);
      console.log(result);   
    })
    // if(this.u.student == null)
    // {
    //   // this.u.student.be_branch=null;
    //   // this.u.student.be_passout=null;
    //   // this.u.student.be_project_details=null;
    //   // this.u.student.be_project_name=null;

    //   // this.u.student.me_branch=null;
    //   // this.u.student.me_passout=null;
    //   // this.u.student.me_project_details=null;
    //   // this.u.student.me_project_name=null;

    // }
 
    // if(this.u.adr == null)
    // {
    //   console.log("In null");
    //   // this.u.adr.cellNo="-";
    //   // this.u.adr.city="-";
    //   // this.u.adr.country="-";
    //   // this.u.adr.state="-";
    //   this.addrNotEmpty=!this.addrNotEmpty;

    //   if(this.u.adr != null)
    //   {
    //     console.log("In not null");

    //     // this.u.adr.cellNo="-";
    //     // this.u.adr.city="-";
    //     // this.u.adr.country="-";
    //     // this.u.adr.state="-";
    //     this.addrNotEmpty=!this.addrNotEmpty;
  
    //   }
  //  }
    
    // console.log(user);
    // let observalbleResult=this.service.SelectbyNo(user)
    // observalbleResult.subscribe((result)=>{
    //   console.log(result);
    //   this.u=result;
    //   console.log(this.u.id);
   // });

   }


}
