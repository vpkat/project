import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddFacultyNoticeComponent } from './add-faculty-notice.component';

describe('AddFacultyNoticeComponent', () => {
  let component: AddFacultyNoticeComponent;
  let fixture: ComponentFixture<AddFacultyNoticeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddFacultyNoticeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddFacultyNoticeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
