import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminChatDeleteComponent } from './admin-chat-delete.component';

describe('AdminChatDeleteComponent', () => {
  let component: AdminChatDeleteComponent;
  let fixture: ComponentFixture<AdminChatDeleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminChatDeleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminChatDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
