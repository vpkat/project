package com.app.pojos;


import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "student_info")
public class StudentInfo 
{
	@JsonProperty(value="no")
	Integer sid;
	double ssc,hsc,be,me;
	String be_project_name;
	String me_project_name;
    String cdac_project_name;
    String be_project_details;
    String me_project_details;
    String cdac_project_details;
        
	String be_passout;
	String me_passout;

	int gap;
	String be_branch;
	String me_branch;

	
	private User users;

// <================================= Constructor Start ========================================>

	public StudentInfo()
	{
       System.out.println("Inside StudentInfo ctor");
    }




public StudentInfo(double ssc, double hsc, double be, double me, String be_project_name, String me_project_name,
		String cdac_project_name, String be_project_details, String me_project_details, String cdac_project_details,
		String be_passout, String me_passout, int gap, String be_branch, String me_branch) {
	super();
	this.ssc = ssc;
	this.hsc = hsc;
	this.be = be;
	this.me = me;
	this.be_project_name = be_project_name;
	this.me_project_name = me_project_name;
	this.cdac_project_name = cdac_project_name;
	this.be_project_details = be_project_details;
	this.me_project_details = me_project_details;
	this.cdac_project_details = cdac_project_details;
	this.be_passout = be_passout;
	this.me_passout = me_passout;
	this.gap = gap;
	this.be_branch = be_branch;
	this.me_branch = me_branch;
}




// <================================= Constructor end ========================================>
	
	
// <================================= Getter Start ========================================>
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getSid() {
		return sid;
	}

	public double getSsc() {
		return ssc;
	}

	public double getHsc() {
		return hsc;
	}
	
	
	  public double getBe() 
	  {
			return be;
	  }

	  public double getMe()
	  {
		   return me;
	  }

	 public String getBe_project_name()
	 {
		  return be_project_name;
	 }

	 public String getMe_project_name() 
	 {
		 return me_project_name;
	 }

	 public String getCdac_project_name() 
	 {
	 	return cdac_project_name;
	 }

	 public String getBe_project_details()
	 {
		 return be_project_details;
	 }

	 public String getMe_project_details() 
	 {
		return me_project_details;
	 }
	 public String getCdac_project_details()
	 {
		return cdac_project_details;
	 }

	 public String getBe_passout() 
	 {
		return be_passout;
	 }

	 public String getMe_passout() 
	 {
	   return me_passout;
	 }

	 public int getGap() 
	 {
			return gap;
	 }
	 
	 public String getBe_branch() 
	 {
			return be_branch;
	 }

	 public String getMe_branch() 
	  {
			return me_branch;
	  }



	@OneToOne
	@JoinColumn(name = "uid")
	@JsonIgnore
	public User getUsers() {
		return users;
	}


// <================================= Getter End ========================================>

	
// <================================= Setter Start ========================================>

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public void setSsc(double ssc) {
		this.ssc = ssc;
	}

	public void setHsc(double hsc) {
		this.hsc = hsc;
	}



	public void setGap(int gap) {
		this.gap = gap;
	}



	public void setUsers(User users) {
		this.users = users;
	}
	
	public void setBe(double be) {
		this.be = be;
	}


	public void setMe(double me) {
		this.me = me;
	}


	public void setBe_project_name(String be_project_name) {
		this.be_project_name = be_project_name;
	}


	public void setMe_project_name(String me_project_name) {
		this.me_project_name = me_project_name;
	}


	public void setCdac_project_name(String cdac_project_name) {
		this.cdac_project_name = cdac_project_name;
	}


	public void setBe_project_details(String be_project_details) {
		this.be_project_details = be_project_details;
	}


	public void setMe_project_details(String me_project_details) {
		this.me_project_details = me_project_details;
	}


	public void setCdac_project_details(String cdac_project_details) {
		this.cdac_project_details = cdac_project_details;
	}


	public void setBe_passout(String be_passout) {
		this.be_passout = be_passout;
	}


	public void setMe_passout(String me_passout) {
		this.me_passout = me_passout;
	}


	public void setBe_branch(String be_branch) {
		this.be_branch = be_branch;
	}


	public void setMe_branch(String me_branch) {
		this.me_branch = me_branch;
	}



// <================================= Setter End ========================================>

// <================================= toString Start ========================================>



	@Override
	public String toString() {
		return "StudentInfo [ssc=" + ssc + ", hsc=" + hsc + ", be=" + be + ", me=" + me + ", be_project_name="
				+ be_project_name + ", me_project_name=" + me_project_name + ", cdac_project_name=" + cdac_project_name
				+ ", be_project_details=" + be_project_details + ", me_project_details=" + me_project_details
				+ ", cdac_project_details=" + cdac_project_details + ", be_passout=" + be_passout + ", me_passout="
				+ me_passout + ", gap=" + gap + ", be_branch=" + be_branch + ", me_branch=" + me_branch + "]";
	}



  


	
// <================================= toString End ========================================>

	
}
