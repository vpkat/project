package com.app.dao;

import java.util.List;

import com.app.pojos.User;

public interface IAdminDao
{
	 List<User> getAllUser();
	 User getUserById(int id);
	 void deleteById(User u);
	 User addUserDetails(User u);
     void updateUser(User oldU, User u);

}
