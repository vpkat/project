import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
/*
userdetails=
{
  "id": "",
  "course": "",
  "email": "",
  "name": "",
  "password": "",
  "role": "" 
}
*/
public userdetails:any;
constructor(private route:ActivatedRoute,
  private router:Router,
  private service:DataService) 
{ }
  ngOnInit() 
  {
    this.route.paramMap.subscribe((result)=>{
      let id=result.get("id");

 
       let observabelResult = this.service.SelectbyNo(id);
        console.log(observabelResult);
        observabelResult.subscribe((data)=>{
          console.log(data);
  
          this.userdetails=data;
        })
       
   });
  }

  Update()
  {
    console.log(this.userdetails);

    let observabelResult = this.service.Update(this.userdetails);
    observabelResult.subscribe((result)=>{
      console.log(result);

      this.router.navigate(['/user_details']);
    })
  }

}
