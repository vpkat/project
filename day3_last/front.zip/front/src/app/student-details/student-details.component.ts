import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-student-details',
  templateUrl: './student-details.component.html',
  styleUrls: ['./student-details.component.css']
})
export class StudentDetailsComponent implements OnInit {
  users:any;
  user=
  {
    "id":"",
    "course":"",
    "email":"",
    "name":"",
    "password":"",
    "role":""
  }
  u:any;
  constructor(private service:DataService,
    private authService:AuthService, 
    private router:Router) { }
  ngOnInit()
   {
    this.users= JSON.parse(window.sessionStorage.getItem("user"));
   
    console.log(this.users);
     this.u=this.users;
    console.log(this.users.id);

    if(this.u.student == null)
    {
      // this.u.student.be_branch=null;
      // this.u.student.be_passout=null;
      // this.u.student.be_project_details=null;
      // this.u.student.be_project_name=null;

      // this.u.student.me_branch=null;
      // this.u.student.me_passout=null;
      // this.u.student.me_project_details=null;
      // this.u.student.me_project_name=null;

    }
    else if(this.u.student.me == 0)
    {
      this.u.student.me_branch="-";
      this.u.student.me_passout="-";
      this.u.student.me_project_details="-";
      this.u.student.me_project_name="-";

    }
   else if(this.u.student.be == 0)
    {
      this.u.student.be_branch="-";
      this.u.student.be_passout="-";
      this.u.student.be_project_details="-";
      this.u.student.be_project_name="-";

    }
    if(this.u.adr == null)
    {
      // this.u.adr.cellNo="-";
      // this.u.adr.city="-";
      // this.u.adr.country="-";
      // this.u.adr.state="-";

    }
    
    // console.log(user);
    // let observalbleResult=this.service.SelectbyNo(user)
    // observalbleResult.subscribe((result)=>{
    //   console.log(result);
    //   this.u=result;
    //   console.log(this.u.id);
   // });

   }
   logout()
   {
    this.authService.SignOut();
    this.router.navigate(['login']);
   }

}
