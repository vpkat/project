import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-admin-chat-delete',
  templateUrl: './admin-chat-delete.component.html',
  styleUrls: ['./admin-chat-delete.component.css']
})
export class AdminChatDeleteComponent implements OnInit {

  constructor(private route:ActivatedRoute,
    private router:Router,
    private service:DataService) {}
  ngOnInit()
  {
    this.route.paramMap.subscribe((result)=>{
      let id=result.get("cid");
 
       let observabelResult = this.service.DeleteChatById(id);
 
       observabelResult.subscribe((data)=>{
         console.log(data);
 
          this.router.navigate(['/admin_chat_page']);
       })
     });
  }

}
