import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-add-student-info',
  templateUrl: './add-student-info.component.html',
  styleUrls: ['./add-student-info.component.css']
})
export class AddStudentInfoComponent implements OnInit {

  public userdetails:any;
  public addr:any;
  users: any;
  i:any;
  constructor(private route:ActivatedRoute,
    private router:Router,
    private service:DataService) 
  { }
    ngOnInit() 
    {
      // this.route.paramMap.subscribe((result)=>{
      //   let id=result.get("id");
  
   
      //    let observabelResult = this.service.SelectbyNo(id);
      //     console.log(observabelResult);
      //     observabelResult.subscribe((data)=>{
      //       console.log(data);
    
      //       this.userdetails=data;
      //     })
         
      // });
      this.users= JSON.parse(window.sessionStorage.getItem("user"));
    
      this.i=this.users.id;
      console.log(this.users);
        let observabelResult = this.service.SelectbyNo(this.i);
      observabelResult.subscribe((data)=>{
        console.log(data);

        this.addr=data;
      })
    
    }
    Update()
    {
      console.log(this.userdetails);

      let observabelResult = this.service.UpdateAddress(this.users,this.addr.adr);
      observabelResult.subscribe((result)=>{
        console.log(result);
        console.log(this.addr);
        // let id=this.users.id;
        //  let res=this.service.SelectbyNo(id);
        //  window.sessionStorage.removeItem("user");
        //  res.subscribe((result)=>{
        //    console.log(result);
        //    console.log("result");

        //   window.sessionStorage.setItem("user",JSON.stringify(result));
          

        // })
        this.router.navigate(['/student_details']);
        
      })
    }
}
