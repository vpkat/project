package com.app.dao;

import java.util.List;

import javax.persistence.RollbackException;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Address;
import com.app.pojos.StudentInfo;
import com.app.pojos.User;

@Repository
@Transactional
public class UserDaoImp implements IUserDao {

	@Autowired
	SessionFactory sf;
	@Override
	public User addAddress(User u) 
	{
		sf.getCurrentSession().update(u);
		return u;
	}
	
	@Override
	public void updateAddress(Address olda, Address a) 
	{
           olda.setCellNo(a.getCellNo());
           olda.setCity(a.getCity());
           olda.setCountry(a.getCountry());
           olda.setState(a.getState());
           
           sf.getCurrentSession().update(olda);
          
	}

	@Override
	public User addStudenInfo(User u) 
	{
		sf.getCurrentSession().update(u);
		return u;
	}

	@Override
	public void updateStudentInfo(StudentInfo oldStudentInfo, StudentInfo s)
	{
        oldStudentInfo.setBe(s.getBe());
        oldStudentInfo.setBe_branch(s.getBe_branch());
        oldStudentInfo.setBe_passout(s.getBe_passout());
        oldStudentInfo.setBe_project_details(s.getBe_project_details());
        oldStudentInfo.setBe_project_name(s.getBe_project_name());
        oldStudentInfo.setCdac_project_details(s.getCdac_project_details());
        oldStudentInfo.setCdac_project_name(s.getCdac_project_name());
        oldStudentInfo.setGap(s.getGap());
        oldStudentInfo.setHsc(s.getHsc());
        oldStudentInfo.setMe(s.getMe());
        oldStudentInfo.setMe_branch(s.getMe_branch());
        oldStudentInfo.setMe_passout(s.getMe_passout());
        oldStudentInfo.setMe_project_details(s.getMe_project_details());
        oldStudentInfo.setMe_project_name(s.getMe_project_name());
        oldStudentInfo.setSsc(s.getSsc());
        
		
		sf.getCurrentSession().update(oldStudentInfo);
	}
    
	@Override
	public User validateUser(User u)
	{
		System.out.println("inside validate dao "+u);
		String jpql="select u from User u where u.id=:i and u.password=:pass";
		
//		try {
//			return sf.getCurrentSession().createQuery(jpql,User.class).setParameter("i", u.getId()).setParameter("pass", u.getPassword()).getSingleResult();
//		}
//			catch (Exception e)
//		{
//			 
//				return null;
//		}
		return sf.getCurrentSession().createQuery(jpql,User.class).setParameter("i", u.getId()).setParameter("pass", u.getPassword()).getSingleResult();

		/*
		 * if(user != null) { return user; } else { System.out.println("null"); return
		 * null; }
		 */

	}
}
