import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteByAdminComponent } from './delete-by-admin.component';

describe('DeleteByAdminComponent', () => {
  let component: DeleteByAdminComponent;
  let fixture: ComponentFixture<DeleteByAdminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteByAdminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteByAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
