import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-notice-home',
  templateUrl: './notice-home.component.html',
  styleUrls: ['./notice-home.component.css']
})
export class NoticeHomeComponent implements OnInit {
  public notices:any;
  constructor(private service:DataService) { }

  ngOnInit() {
    let observalbleResult=this.service.SelectNotice();
    observalbleResult.subscribe((result)=>{
      //console.log(result);
      this.notices=result;
      console.log(result);
    
    })
   
  }

}
