package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.app.dao.IAdminDao;
import com.app.pojos.User;

@RestController
@CrossOrigin
@RequestMapping("/admin")
public class AdminController 
{
	@Autowired
	private IAdminDao dao;

	  
		// REST request handling method to get list of user
		@GetMapping
		public ResponseEntity<?> listUsers() {
			System.out.println("in list user");
			List<User> allUser = dao.getAllUser();
			if (allUser.size() == 0)
				return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
			return new ResponseEntity<List<User>>(allUser, HttpStatus.OK);
		}
		
		
		// REST request handling method to get user by id
		@GetMapping("/{id}")
		public ResponseEntity<?> getUserDetails(@PathVariable int id)
		{
			System.out.println("in user dtls " +id);
			User u=dao.getUserById(id);
			if(u == null)
				return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
			return new ResponseEntity<User>(u,HttpStatus.OK);
			
		}

}
