package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.app.dao.IAdminDao;
import com.app.dao.IChatDao;
import com.app.dao.IUserDao;
import com.app.pojos.Address;
import com.app.pojos.Chat;
import com.app.pojos.User;



@RestController
@CrossOrigin
@RequestMapping("/chat")
public class ChatController 
{
   @Autowired
   IAdminDao daoa;
	
   @Autowired
   IUserDao daou;
   
   @Autowired
   IChatDao daoc;
   
  


	@GetMapping
	public ResponseEntity<?> listMsg() {
		System.out.println("in list user");
		List<Chat> allChat = daoc.getAllChat();
		if (allChat.size() == 0)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<List<Chat>>(allChat, HttpStatus.OK);
	}
   
	@PostMapping("/add_chat/{id}")
	public ResponseEntity<?> addAddress(@PathVariable int id, @RequestBody Chat c )
	{
		System.out.println("Inside add address method "+c);
		//remove below line in angular
		User u=daoa.getUserById(id);
		System.out.println("user in add address method "+u);
	  
		System.out.println(u.getRole());
		c.setNames(u.getName());
		u.addMessage(c);
		
		try {
			return new ResponseEntity<User>(daoc.addChat(u), HttpStatus.CREATED);
		} catch (RuntimeException e1) {
			e1.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
   
   
}
