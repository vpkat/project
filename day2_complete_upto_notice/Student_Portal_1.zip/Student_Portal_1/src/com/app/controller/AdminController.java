package com.app.controller;

import java.util.List;

import javax.jws.soap.SOAPBinding.Use;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.app.dao.IAdminDao;
import com.app.dao.IUserDao;
import com.app.pojos.Course;
import com.app.pojos.Notice;
import com.app.pojos.NoticeType;
import com.app.pojos.User;

@RestController
@CrossOrigin
@RequestMapping("/admin")
public class AdminController 
{
	@Autowired
	private IAdminDao dao;
	  
		// REST request handling method to get list of user
		@GetMapping
		public ResponseEntity<?> listUsers() {
			System.out.println("in list user");
			List<User> allUser = dao.getAllUser();
			if (allUser.size() == 0)
				return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
			return new ResponseEntity<List<User>>(allUser, HttpStatus.OK);
		}
		
		
		// REST request handling method to get user by id
		@GetMapping("/{id}")
		public ResponseEntity<?> getUserDetails(@PathVariable int id)
		{
			System.out.println("in user dtls " +id);
			User u=dao.getUserById(id);
			System.out.println(u);
			if(u == null)
				return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
			return new ResponseEntity<User>(u,HttpStatus.OK);
			
		}
		
		//Rest delete by id
		@DeleteMapping("/{id}")
		public void deleteUserById(@PathVariable int id)
		{
			System.out.println("in user delete by id " +id);
			User u = dao.getUserById(id);
			dao.deleteById(u);
			
		}
		
		// REST request handling method to create new resoures : User
		@PostMapping
		public ResponseEntity<?> addUserDetails(@RequestBody User u) {
			System.out.println("in add user dtls " + u);
			try {
				return new ResponseEntity<User>(dao.addUserDetails(u), HttpStatus.CREATED);
			} catch (RuntimeException e1) {
				e1.printStackTrace();
				return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
			}

		}
		
		// REST request handling method to create new resoures : User
		@PutMapping("/{id}")
		public ResponseEntity<?> updateUserDetails(@PathVariable int id,@RequestBody User u) {
			u.setId(id);
			System.out.println("in add user dtls " + u);
			
			User oldU=dao.getUserById(u.getId());
			       dao.updateUser(oldU,u);
			
			return null;

		}
		
//-------------------------------------------------------- Notice Start ---------------------------------------------------
		// REST request handling method to add new notice : User
		@PostMapping("/notice")
		public ResponseEntity<?> addNotice(@RequestBody Notice n) {
			System.out.println("in add user dtls " + n);
			try {
				return new ResponseEntity<Notice>(dao.addNotice(n), HttpStatus.CREATED);
			} catch (RuntimeException e1) {
				e1.printStackTrace();
				return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
			}

		}
		
		@GetMapping("/notice")
		public ResponseEntity<?> getNotice(@PathVariable Course course,@PathVariable NoticeType notice) {
			List<Notice> allUser = dao.getAllNotices(course,notice);
			if (allUser.size() == 0)
				return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
			return new ResponseEntity<List<Notice>>(allUser, HttpStatus.OK);

		}
		
//-------------------------------------------------------- Notice end ---------------------------------------------------


}
