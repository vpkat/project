import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {

  user=
  {
    "course": "",
    "email": "",
    "name": "",
    "password": "",
    "role": "" 
  }
 
  constructor(private route:ActivatedRoute,
    private router:Router,
    private service:DataService) 
{ }

  ngOnInit() {
  }
  Insert()
  {
    console.log(this.user);

    let observabelResult = this.service.Insert(this.user);
    observabelResult.subscribe((result)=>{
      console.log(result);

      this.router.navigate(['/admin_home']);
    })
  }

}
