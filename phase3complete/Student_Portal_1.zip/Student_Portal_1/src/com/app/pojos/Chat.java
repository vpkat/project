package com.app.pojos;

import java.util.Date;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="chat")
public class Chat
{
  Integer cid;
  String message;
  Role role;
  String names;
  User user;
  
  
  public Chat() 
  { }
  

	public Chat(String message, Role role, String names) {
	super();
	this.message = message;
	this.role = role;
	this.names = names;
}



	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getCid() {
		return cid;
	}
	
    
	public String getMessage() {
		return message;
	}
	
	@ManyToOne
    @JoinColumn(name = "mid")
	@JsonIgnore
	public User getUser() {
		return user;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setUser(User user) {
		this.user = user;
	}


	public Role getRole() {
		return role;
	}


	public void setRole(Role role) {
		this.role = role;
	}


	public String getNames() {
		return names;
	}


	public void setNames(String names) {
		this.names = names;
	}


	@Override
	public String toString() {
		return "Chat [cid=" + cid + ", message=" + message + ", role=" + role + ", names=" + names + "]";
	}
	
	

    
   
  
}
