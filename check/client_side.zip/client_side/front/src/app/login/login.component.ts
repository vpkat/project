import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router, ActivatedRoute } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
userdetails=
{
  id:"",
  course:null,
  email:null,
  name:null,
  password:"",
  role:null
  
}
users:any;
message;
  constructor(private authService:AuthService,private dataService:DataService,private route:ActivatedRoute,
    private router:Router) { }

  ngOnInit() {
  }
   
  SignIn()
  {
    console.log(this.userdetails.id,this.userdetails.password);
    let observableResult=this.dataService.CheckUser(this.userdetails);
    observableResult.subscribe((result)=>{
      console.log(result);
      if(result != null)
      {
        console.log("hi");
        
        this.authService.setSession(result);
        this.users=result;
        console.log(this.users.id);
        if(this.users.role == "ADMIN")
        {
          console.log("admin")
          this.router.navigate(['admin_home']);
        }
        else if(this.users.role == "STUDENT")
        {
          console.log("student")

          this.router.navigate(['student_home']);
        }
        else
        {
          console.log("faculty")

          this.router.navigate(['faculty_home']);

        }
      }
        else
        {
          this.message="Username or Password is wrong.";

        }

    })
  }
}
