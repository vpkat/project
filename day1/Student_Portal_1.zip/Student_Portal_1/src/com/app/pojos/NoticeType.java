package com.app.pojos;

public enum NoticeType 
{
   DAC,DMC,DBDA
}
