package com.app.dao;

import java.util.List;

import com.app.pojos.Course;
import com.app.pojos.Notice;
import com.app.pojos.NoticeType;
import com.app.pojos.User;

public interface IAdminDao
{
	 List<User> getAllUser();
	 User getUserById(int id);
	 void deleteById(User u);
	 User addUserDetails(User u);
     void updateUser(User oldU, User u);
	 Notice addNotice(Notice n);
	List<Notice> getAllNotices(Course course, NoticeType notice);

}
