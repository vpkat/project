import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-chat-delete',
  templateUrl: './admin-chat-delete.component.html',
  styleUrls: ['./admin-chat-delete.component.css']
})
export class AdminChatDeleteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
